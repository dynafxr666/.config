#!/bin/bash
status="$(playerctl status)"

case $status in
   Paused)
	   echo "$(playerctl metadata title) $(playerctl metadata artist) ($status)"
	;;
   *)
	echo "$(playerctl metadata title) $(playerctl metadata artist)"
	;;
esac
