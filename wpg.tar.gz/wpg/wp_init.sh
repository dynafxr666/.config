#!/usr/bin/env bash
wpg -rs 'D5FRjHb.png' 'D5FRjHb.png'